import UIKit
import FlutterPluginRegistrant
import Flutter
import flutter_boost

@UIApplicationMain
class AppDelegate: FlutterAppDelegate {
    override func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        GeneratedPluginRegistrant.register(with: self)
        flutterSetup()
        window = UIWindow(frame: UIScreen.main.bounds)
        window?.rootViewController = CHYTabBarController()
        window?.makeKeyAndVisible()
        return true
    }

    func flutterSetup(){
        let router = PlatformRouterImp.init();
        FlutterBoostPlugin.sharedInstance().startFlutter(with: router, onStart: { (engine) in
        });
    }
    
}

