import UIKit
import flutter_boost

class PlatformRouterImp: NSObject, FLBPlatform {
    func open(_ url: String, urlParams: [AnyHashable : Any], exts: [AnyHashable : Any], completion: @escaping (Bool) -> Void) {
        
        var animated = true;
        if exts["animated"] != nil{
           animated = exts["animated"] as! Bool;
        }
        
       let vc = CHYFlutterViewController.init();
        vc.setName(url, params: urlParams);
        vc.hidesBottomBarWhenPushed = true;
        self.navigationController().pushViewController(vc, animated: animated);
        
        completion(true);
    }
    
    func present(_ url: String, urlParams: [AnyHashable : Any], exts: [AnyHashable : Any], completion: @escaping (Bool) -> Void) {
        var animated = true;
        if exts["animated"] != nil{
            animated = exts["animated"] as! Bool;
        }
        
        if url.contains("native://") {
            
        }else if url.contains("flutter://") {
            let vc = CHYFlutterViewController.init();
            vc.hidesBottomBarWhenPushed = true;
            vc.setName(url, params: urlParams);
            navigationController().present(vc, animated: animated) {
                completion(true);
            };
        }
    }
    
    func close(_ uid: String, result: [AnyHashable : Any], exts: [AnyHashable : Any], completion: @escaping (Bool) -> Void) {
 var animated = false;
        if exts["animated"] != nil{
            animated = exts["animated"] as! Bool;
        }
        let presentedVC = self.navigationController().presentedViewController;
        let vc = presentedVC as? CHYFlutterViewController;
        if vc?.uniqueIDString() == uid {
            vc?.dismiss(animated: animated, completion: {
                completion(true);
            });
        }else{
            self.navigationController().popViewController(animated: animated);
        }
    }
    
    func navigationController() -> UINavigationController {
        let delegate = UIApplication.shared.delegate as! AppDelegate
        let rootVC = delegate.window?.rootViewController as! CHYTabBarController
        let navigationController = rootVC.selectedViewController as! UINavigationController
        return navigationController;
    }
}
