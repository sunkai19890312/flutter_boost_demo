import UIKit
import Flutter
import flutter_boost

class CHYFlutterViewController: FLBFlutterViewContainer {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated);
        self.navigationController?.setNavigationBarHidden(true, animated: false);
        self.view.setNeedsLayout()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super .viewDidDisappear(animated);
        self.navigationController?.setNavigationBarHidden(false, animated: false);
    }
    
}
