
import UIKit

class CHYTabBarController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.white
        let attrNormal = [NSAttributedString.Key.foregroundColor : UIColor.orange]
        let attrSelected = [NSAttributedString.Key.foregroundColor : UIColor.blue]
        let homeImage = UIImage(named: "icon_")?.withRenderingMode(.alwaysOriginal)
        let homeSelect = UIImage(named: "icon_1")?.withRenderingMode(.alwaysOriginal)
        let homeFlutterViewController = CHYFlutterViewController.init();
        homeFlutterViewController.setName("aaaaaaa", params: [:]);
        let home = UINavigationController.init(rootViewController: homeFlutterViewController)
        home.tabBarItem = UITabBarItem(title: "demo", image: homeImage, selectedImage: homeSelect)
        home.tabBarItem.setTitleTextAttributes(attrNormal, for: .normal)
        home.tabBarItem.setTitleTextAttributes(attrSelected, for: .selected)
        
        self.setViewControllers([home], animated: true)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
}
