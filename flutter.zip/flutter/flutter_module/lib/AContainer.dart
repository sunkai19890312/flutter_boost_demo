import 'package:flutter/material.dart';
import 'package:flutter_boost/flutter_boost.dart';

class AContainer extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return AAAAA();
  }
}

class AAAAA extends StatefulWidget {
  AAAAA({Key key, this.title}) : super(key: key);
  final String title;
  @override
  AAAAAState createState() => AAAAAState();
}

class AAAAAState extends State<AAAAA> {
  Widget build(BuildContext context) {
    return  new MaterialButton(
          color: Colors.blue,
          textColor: Colors.white,
          child: new Text('点我'),
          onPressed: () {
                FlutterBoost.singleton.open("bbbbbbb");
          },
      );
  }
}
