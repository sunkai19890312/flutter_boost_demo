import 'package:flutter/material.dart';
import 'package:flutter_boost/flutter_boost.dart';

class BContainer extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return BBBBB();
  }
}

class BBBBB extends StatefulWidget {
  BBBBB({Key key, this.title}) : super(key: key);
  final String title;
  @override
  BBBBBState createState() => BBBBBState();
}

class BBBBBState extends State<BBBBB> {
  @override
  Widget build(BuildContext context) {
    return  
      new MaterialButton(
          color: Colors.blue,
          textColor: Colors.white,
          child: new Text('点我'),
          onPressed: () {
                FlutterBoost.singleton.open("aaaaaaa");
          },
      );
  }

}
