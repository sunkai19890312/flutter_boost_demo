
import 'package:flutter/material.dart';
import 'package:flutter_boost/flutter_boost.dart';
import 'package:flutter_module/AContainer.dart';
import 'package:flutter_module/BContainer.dart';

void main() {
    runApp(MyApp());
}

class MyApp extends StatefulWidget {
    @override
    _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
    @override
    void initState() {
      super.initState();
      FlutterBoost.singleton.registerPageBuilders({
          'aaaaaaa': (pageName, params, _) => AContainer(),
          'bbbbbbb': (pageName, params, _) => BContainer(),
      });
    }
    
    @override
    Widget build(BuildContext context) {
      return MaterialApp(
          builder: FlutterBoost.init(postPush: _onRoutePushed),
          home: Container());
    }
    
    void _onRoutePushed(
        String pageName, String uniqueId, Map params, Route route, Future _) {
    }
}




